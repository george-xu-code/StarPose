# Copyright (c) OpenMMLab. All rights reserved.
from .ubody3d_dataset import UBody3dDataset

__all__ = ['UBody3dDataset']
