# Copyright (c) OpenMMLab. All rights reserved.
from .deepfashion2_dataset import DeepFashion2Dataset
from .deepfashion_dataset import DeepFashionDataset

__all__ = ['DeepFashionDataset', 'DeepFashion2Dataset']
