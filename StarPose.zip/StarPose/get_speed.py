import os

os.system("python tools/analysis_tools/speed_test.py configs/body_2d_keypoint/simcc/coco/starpose-18_1e-3_260e_256x192_simcc2.py --batch-size 1 --device cuda:0")