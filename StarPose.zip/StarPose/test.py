
import os
os.system('python tools/test.py configs/body_2d_keypoint/simcc/coco/starpose-18_1e-3_260e_256x192_simcc2.py work_dirs/starpose-18_1e-3_260e_256x192_simcc2/best_coco_AP_epoch_260.pth')

